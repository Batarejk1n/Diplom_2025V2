import React, { useState } from "react";
import TopMenu from "./components/TopMenu.jsx";
import Sidebar from "./components/Sidebar.jsx";
import Content from "./components/Content.jsx";
import Footer from "./components/Footer.jsx";
import RegistrationForm from "./components/RegistrationForm.jsx"; // Форма регистрации
import LoginForm from "./components/LoginForm.jsx"; // Форма входа
import "./index.css";

function App() {
  // Состояния приложения
  const [isSidebarOpen, setSidebarOpen] = useState(false); // Открытие/закрытие бокового меню
  const [showRegistration, setShowRegistration] = useState(false); // Показ формы регистрации
  const [showLogin, setShowLogin] = useState(false); // Показ формы входа
  const [activeChat, setActiveChat] = useState(null); // Активный чат

  // Переключение бокового меню
  const toggleSidebar = () => {
    setSidebarOpen((prev) => !prev);
  };

  // Переключение формы регистрации
  const toggleRegistration = () => {
    setShowRegistration((prev) => !prev);
    setShowLogin(false); // Скрываем форму входа, если открыта
  };

  // Переключение формы входа
  const toggleLogin = () => {
    setShowLogin((prev) => !prev);
    setShowRegistration(false); // Скрываем форму регистрации, если открыта
  };

  return (
    <div className="App">
      {/* Верхнее меню */}
      {!showRegistration && !showLogin && (
        <TopMenu
          onToggleSidebar={toggleSidebar}
          onToggleRegistration={toggleRegistration}
          onToggleLogin={toggleLogin}
          isSidebarOpen={isSidebarOpen} // Передаем состояние бокового меню
        />
      )}

      {/* Боковое меню */}
      {!showRegistration && !showLogin && (
        <Sidebar
          isOpen={isSidebarOpen}
          setActiveChat={setActiveChat} // Управляем активным чатом
        />
      )}

      {/* Основной контент или форма регистрации/входа */}
      {showRegistration ? (
        <RegistrationForm onClose={toggleRegistration} />
      ) : showLogin ? (
        <LoginForm onClose={toggleLogin} />
      ) : (
        <Content
          isSidebarOpen={isSidebarOpen}
          activeChat={activeChat} // Передаем активный чат
        />
      )}

      {/* Подвал */}
      <Footer />
    </div>
  );
}

export default App;