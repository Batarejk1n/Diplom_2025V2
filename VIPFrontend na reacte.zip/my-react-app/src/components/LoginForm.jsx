import React from "react";

function LoginForm({ onClose }) {
  return (
    <div className="login-form">
      <h2>Вход</h2>
      <form>
        <label>
          Email:
          <input type="email" placeholder="Введите email" required />
        </label>
        <br />
        <label>
          Пароль:
          <input type="password" placeholder="Введите пароль" required />
        </label>
        <br />
        <button type="submit">Войти</button>
      </form>
      <button className="close-button" onClick={onClose}>
        Закрыть
      </button>
    </div>
  );
}

export default LoginForm;