import React, { useState } from "react";

function DeepSeekChat() {
  const [messages, setMessages] = useState([]);
  const [inputValue, setInputValue] = useState("");

  const sendMessage = async () => {
    if (!inputValue.trim()) return;
  
    const userMessage = { id: Date.now(), text: inputValue, sender: "user" };
    setMessages((prevMessages) => [...prevMessages, userMessage]);
    setInputValue("");
  
    try {
        const response = await fetch("https://api.deepseek.com", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${import.meta.env.VITE_DEEPSEEK_API_KEY}`,
            },
            body: JSON.stringify({
              prompt: inputValue,
              max_tokens: 50,
            }),
          });
  
      if (!response.ok) {
        throw new Error(`Ошибка HTTP: ${response.status}`);
      }
  
      const data = await response.json();
  
      if (data.choices && data.choices.length > 0) {
        const botMessage = { id: Date.now(), text: data.choices[0].text, sender: "bot" };
        setMessages((prevMessages) => [...prevMessages, botMessage]);
      } else {
        console.error("Ответ от API не содержит данных.");
        setMessages((prevMessages) => [
          ...prevMessages,
          { id: Date.now(), text: "Не удалось получить ответ от сервера.", sender: "bot" },
        ]);
      }
    } catch (error) {
      console.error("Ошибка при отправке запроса:", error);
      setMessages((prevMessages) => [
        ...prevMessages,
        { id: Date.now(), text: `Ошибка: ${error.message}`, sender: "bot" },
      ]);
    }
  };

  return (
    <div className="deepseek-chat">
      <h3>Chat GPT</h3>
      <div className="chat-box">
        {messages.map((message) => (
          <div key={message.id} className={`message ${message.sender}`}>
            {message.text}
          </div>
        ))}
      </div>
      <div className="chat-input">
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          placeholder="Введите сообщение..."
        />
        <button onClick={sendMessage}>Отправить</button>
      </div>
    </div>
  );
}

export default DeepSeekChat;