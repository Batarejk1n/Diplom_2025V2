// src/components/FAQ.jsx

import React from "react";

function FAQ() {
  return (
    <div>
      <h2>ИИУУ</h2>
      <p>ИИУУ</p>
    </div>
  );
}

export default FAQ;