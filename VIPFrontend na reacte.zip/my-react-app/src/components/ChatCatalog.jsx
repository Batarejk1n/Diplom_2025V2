import React, { useState, useRef } from 'react';

const ChatCatalog = () => {
  const [chats, setChats] = useState([]);
  const catalogItemsRef = useRef(null);

  const addChat = () => {
    const chatName = prompt('Введите название чата:');
    if (chatName) {
      setChats([...chats, { id: Date.now(), name: chatName }]);
    }
  };

  const deleteChat = (id) => {
    setChats(chats.filter(chat => chat.id !== id));
  };

  return (
    <div className="chat-catalog">
      <div className="catalog-header">
        <h3>Чаты</h3>
        <button id="addChatButton" onClick={addChat}>+ Добавить чат</button>
      </div>
      <div className="catalog-items" ref={catalogItemsRef}>
        {chats.map(chat => (
          <div key={chat.id} className="chat-item">
            <div>{chat.name}</div>
            <div className="delete-chat" onClick={() => deleteChat(chat.id)}>✖</div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ChatCatalog;