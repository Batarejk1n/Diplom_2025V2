// src/components/Support.jsx

import React from "react";

function Support() {
  return (
    <div>
      <h2>Поддержка</h2>
      <p>Свяжитесь с нами для получения помощи.</p>
    </div>
  );
}

export default Support;