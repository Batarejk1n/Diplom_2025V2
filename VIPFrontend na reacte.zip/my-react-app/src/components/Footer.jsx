function Footer() {
    return (
      <footer>
        © 2023 Orange Topich interactiv
      </footer>
    );
  }
  
  export default Footer;