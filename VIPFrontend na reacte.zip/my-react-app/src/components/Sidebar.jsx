import React from "react";

function Sidebar({ isOpen, setActiveChat }) {
  return (
    <div className={`sidebar ${isOpen ? "active" : ""}`}>
      {/* Заголовок с логотипом */}
      <div className="sidebar-header">
        <img src="public/ATIUMPower.jpg" alt="Логотип" className="sidebar-logo" />
      </div>

      {/* Список кнопок */}
      <ul className="sidebar-list">
        {[
          { name: "Chat GPT", value: "chatgpt" },
          { name: "DeepSeek", value: "deepseek" },
          { name: "DeepL Finder AI", value: "deepl" },
          { name: "FAQ", value: "faq" },
          { name: "Поддержка", value: "support" },
        ].map((item) => (
          <li key={item.value}>
            <button onClick={() => setActiveChat(item.value)}>{item.name}</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Sidebar;