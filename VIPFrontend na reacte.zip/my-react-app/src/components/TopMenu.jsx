import React from "react";

function TopMenu({ onToggleSidebar, onToggleRegistration, onToggleLogin, isSidebarOpen }) {
  const [isDark, setIsDark] = React.useState(false);

  // Переключение темы
  const toggleTheme = () => {
    const newTheme = isDark ? "light" : "dark";
    document.documentElement.setAttribute("data-theme", newTheme);
    localStorage.setItem("theme", newTheme);
    setIsDark(!isDark);
  };

  // При загрузке компонента проверяем сохранённую тему
  React.useEffect(() => {
    const savedTheme = localStorage.getItem("theme");
    if (savedTheme === "dark") {
      setIsDark(true);
      document.documentElement.setAttribute("data-theme", "dark");
    }
  }, []);

  return (
    <div className="top-menu">
      {/* Иконка меню */}
      <button
        className={`menu-icon ${isSidebarOpen ? "open" : ""}`}
        onClick={onToggleSidebar}
      >
        <span></span>
        <span></span>
        <span></span>
      </button>

      <h1>ATIUM</h1> {/* название сайта */}

      <div className="top-menu-actions">
        <button className="notifications" title="Уведомления">🔔</button>
        <button className="profile" onClick={onToggleLogin} title="Профиль">👤</button>

        {/* Переключатель темы в виде ползунка */}
        <label className="theme-switch">
          <input 
            type="checkbox" 
            checked={isDark} 
            onChange={toggleTheme} 
          />
          <span className="slider round"></span>
        </label>
      </div>
    </div>
  );
}

export default TopMenu;