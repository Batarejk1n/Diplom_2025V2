import React from "react";

function RegistrationForm({ onClose }) {
  return (
    <div className="registration-form">
      <h2>Регистрация</h2>
      <form>
        <label>
          Имя пользователя:
          <input type="text" placeholder="Введите имя" required />
        </label>
        <br />
        <label>
          Email:
          <input type="email" placeholder="Введите email" required />
        </label>
        <br />
        <label>
          Пароль:
          <input type="password" placeholder="Введите пароль" required />
        </label>
        <br />
        <button type="submit">Зарегистрироваться</button>
      </form>
      <button className="close-button" onClick={onClose}>
        Закрыть
      </button>
    </div>
  );
}

export default RegistrationForm;