import React from "react";
import ChatGPT from "./ChatGPT.jsx"; // Компонент для Chat GPT
import DeepSeekChat from "./DeepSeekChat.jsx"; // Компонент для DeepSeek
import FAQ from "./FAQ.jsx"; // Компонент для FAQ
import Support from "./Support.jsx"; // Компонент для поддержки
import ChatCatalog from "./ChatCatalog.jsx"; // Импортируем компонент каталога чатов

function Content({ isSidebarOpen, activeChat }) {
  return (
    <div className={`main-content ${isSidebarOpen ? "shifted" : ""}`}>
      {/* Контейнер для двух колонок */}
      <div className="content-container">
        {/* Левая колонка: Каталог чатов */}
        <div className="chat-catalog-column">
          <h2>Каталог чатов</h2>
          <ChatCatalog />
        </div>

        {/* Правая колонка: Основной контент */}
        <div className="main-chat-column">
          {/* Отображаем название выбранного ресурса */}
          {activeChat && <h2>{activeChat.toUpperCase()}</h2>}
          {/* Отображаем содержимое в зависимости от выбранного чата */}
          {activeChat === "chatgpt" && <ChatGPT />}
          {activeChat === "deepseek" && <DeepSeekChat />}
          {activeChat === "deepl" && <div>DeepL Finder AI Content</div>}
          {activeChat === "faq" && <FAQ />}
          {activeChat === "support" && <Support />}
          {/* Если чат не выбран, показываем сообщение */}
          {!activeChat && <div>Выберите чат из бокового меню</div>}
        </div>
      </div>
    </div>
  );
}

export default Content;