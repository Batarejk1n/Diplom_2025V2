import React from "react";

function RegistrationPage() {
  return (
    <div className="registration-page">
      <h2>Регистрация</h2>
      <form>
        <label>
          Имя пользователя:
          <input type="text" placeholder="Введите имя" required />
        </label>
        <br />
        <label>
          Email:
          <input type="email" placeholder="Введите email" required />
        </label>
        <br />
        <label>
          Пароль:
          <input type="password" placeholder="Введите пароль" required />
        </label>
        <br />
        <button type="submit">Зарегистрироваться</button>
      </form>
    </div>
  );
}

export default RegistrationPage;